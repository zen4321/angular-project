import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {

  customers: Observable<Customer[]> = new Observable;

 

  constructor(private customerService: CustomerService,
    private router: Router) {}

 

  ngOnInit() {
    this.reloadData();
  }

 

  reloadData() {
    this.customers  = this.customerService.viewAllCustomers();
  }

 

  removeCustomer(customerId: number) {
    this.customerService.removeCustomer(customerId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

 

  updateCustomer(customerId: number) {
    this.router.navigate(['update', customerId]);
  }

 

  getCustomer(customerId: number){
    this.router.navigate(['details', customerId]);
  }

}
