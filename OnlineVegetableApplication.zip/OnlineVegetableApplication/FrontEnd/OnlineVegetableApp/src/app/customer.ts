import { Address } from "./address";

export class Customer {
    customerId: number = 0;
    name: string = "";
    mobileNo: string = "";
    emailId: string = "";
    password: string = "";
    confirmPassword: string = "";
    address!: Address;
}