package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name="User_details")
public class User {
	@Id
	@NotEmpty(message="User ID is required")
	private int userId;
	@Column(length = 20)
	@NotEmpty(message="Password is required")
	private String password;
	@Column(length = 20)
	@NotEmpty(message="Role is required")
	private String role;
	
	
	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}

	
	public User(@NotEmpty(message = "User ID is required") int userId,
			@NotEmpty(message = "Password is required") String password,
			@NotEmpty(message = "Role is required") String role) {
		super();
		this.userId = userId;
		this.password = password;
		this.role = role;
	}


	public User() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "User [userId=" + userId + ", password=" + password + ", role=" + role + "]";
	}
	
	
	
	}
	
	
	

