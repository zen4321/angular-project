package com.cg.model;

 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

 

@Entity
@Table(name="admin_details")
public class Admin {
    
	@Id
	@Column(name="adminId",length=20)
	@GeneratedValue(strategy = GenerationType.AUTO )
    private int adminId;
    
	@Column(name="adminName",length=20)
	@NotEmpty(message="Name is required")
    private String name;
	
	@Column(name="contactNumber",length=20)
	@NotEmpty(message="Contact Number is required")
    private String contactNumber;
    
	@Column(name="emailId",length=20)
	@NotEmpty(message="Email Id is required")
	@Email(message="Not a valid Email")
    private String emailId;
    
	@Column(name="password",length=20)
	@NotEmpty(message="Password is required")
    private String password;
    
	@Column(name="confirmPassword",length=20)
	@NotEmpty(message="Confirm Password is required")
    private String confirmPassword;
	public Admin() {
		super();
	}
	public Admin(int adminId, String name, String contactNumber, String emailId, String password,
			String confirmPassword) {
		super();
		this.adminId = adminId;
		this.name = name;
		this.contactNumber = contactNumber;
		this.emailId = emailId;
		this.password = password;
		this.confirmPassword = confirmPassword;
	}
	
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", name=" + name + ", contactNumber=" + contactNumber + ", emailId="
				+ emailId + ", password=" + password + ", confirmPassword=" + confirmPassword + "]";
	}

    
 
    
}
 