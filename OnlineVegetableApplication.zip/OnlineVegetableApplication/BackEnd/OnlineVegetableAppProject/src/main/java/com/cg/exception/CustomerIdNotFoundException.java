package com.cg.exception;

public class CustomerIdNotFoundException extends Exception{
	public CustomerIdNotFoundException() {
		super();
	}

	public CustomerIdNotFoundException (String message) {
		super(message);
	}

}
