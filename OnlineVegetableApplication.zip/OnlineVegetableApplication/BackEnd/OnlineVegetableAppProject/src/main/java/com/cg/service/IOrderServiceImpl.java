package com.cg.service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.repository.IOrderRepository;
import com.cg.model.Order;

import com.cg.exception.OrderIdNotFoundException;

@Service
public class IOrderServiceImpl implements IOrderService {

	@Autowired
	IOrderRepository repository;

	@Override
	public Order addOrder(Order order) {
		// TODO Auto-generated method stub
		return repository.save(order);
	}

	@Override
	public Order updateOrderDetails(int orderId,Order order) throws OrderIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<Order> optional = repository.findById(orderId);
		if(optional.isEmpty())
		{
			throw new OrderIdNotFoundException("Order with id"+orderId+"not present");
		}
		optional.get().setOrderId(orderId);
		optional.get().setCustomer(order.getCustomer());
		optional.get().setTotalAmount(order.getTotalAmount());
		optional.get().setOrderDate(order.getOrderDate());
		optional.get().setStatus(order.getStatus());
		optional.get().setVegetables(order.getVegetables());
		
		return repository.save(optional.get());
	}
	
	@Override
	public Order viewOrder(int orderNo) throws OrderIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<Order> optional = repository.findById(orderNo);
		if (optional.isEmpty()) {
			throw new OrderIdNotFoundException("Order with id " + orderNo + " does not Exist");
		}

		return optional.get();

	}

	

	@Override
	public List<Order> viewAllOrders(int custid) {
		// TODO Auto-generated method stub
		List<Order> allorder = repository.findAllByCustId(custid);
		return allorder;
	}

	@Override
	public List<Order> viewOrderListByDate(LocalDate date) {
		// TODO Auto-generated method stub
		List<Order> allorder = repository.findAllByOrderDate(date);
		return allorder;
	}

	@Override
	public List<Order> viewOrderList() {
		// TODO Auto-generated method stub
		List<Order> allorder = repository.findAll();
		return allorder;
	}

	@Override
	public String cancelOrder(int orderNo) throws OrderIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<Order> optional = repository.findById(orderNo);
		if (optional.isEmpty()) {
			throw new OrderIdNotFoundException("Order with id " + orderNo + " does not Exist");
		}
		repository.delete(optional.get());
		return ("Order with id "+ orderNo +"is cancelled");
	}

}

