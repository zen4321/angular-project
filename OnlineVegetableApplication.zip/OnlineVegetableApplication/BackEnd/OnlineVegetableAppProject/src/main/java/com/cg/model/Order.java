package com.cg.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name="order_details")
public class Order {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId;
	@OneToOne
	@JoinColumn(name="customerId")
	private Customer customer;
	private double totalAmount;
	private LocalDate orderDate;
	@Column(length = 20)
	@NotEmpty(message="Status is required")
	private String status;
	@OneToMany 	
    private List<VegetableDTO> vegetables;
	
	public Order() {
		super();
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<VegetableDTO> getVegetables() {
		return vegetables;
	}

	public void setVegetables(List<VegetableDTO> vegetables) {
		this.vegetables = vegetables;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", customer=" + customer + ", totalAmount=" + totalAmount + ", orderDate="
				+ orderDate + ", status=" + status + ", vegetables=" + vegetables + "]";
	}

	public Order(int orderId, Customer customer, double totalAmount, LocalDate orderDate, String status,
			List<VegetableDTO> vegetables) {
		super();
		this.orderId = orderId;
		this.customer = customer;
		this.totalAmount = totalAmount;
		this.orderDate = orderDate;
		this.status = status;
		this.vegetables = vegetables;
	}

	

	
	
	
	
	


}
