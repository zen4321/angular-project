package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.repository.IVegetableMgmtRepository;
import com.cg.model.VegetableDTO;


import com.cg.exception.VegetableIdNotFoundException;

@Service
public class IVegetableMgmtServiceImpl implements IVegetableMgmtService {

	@Autowired
	IVegetableMgmtRepository repository;
	
	
	@Override
	public VegetableDTO addVegetable(VegetableDTO dto) {
		// TODO Auto-generated method stub
		return  repository.save(dto);
		
	}

	@Override
	public VegetableDTO updateVegetable(int vegId,VegetableDTO dto) throws VegetableIdNotFoundException {
		Optional<VegetableDTO> optional = repository.findById(vegId);
		if (optional.isEmpty()) {
			throw new VegetableIdNotFoundException("Vegetable with id " + vegId + " does not Exist");
		}
		optional.get().setVegId(vegId);
		optional.get().setName(dto.getName());
		optional.get().setType(dto.getType());
		optional.get().setCategory(dto.getCategory());
		optional.get().setPrice(dto.getPrice());
		optional.get().setQuantity(dto.getQuantity());
		
		return  repository.save(optional.get());
	}

	@Override
	public String removeVegetable(int vegId) throws VegetableIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<VegetableDTO> optional = repository.findById(vegId);
		if (optional.isEmpty()) {
			throw new VegetableIdNotFoundException("Vegetable with id " + vegId + " does not Exist");
		}
		repository.delete(optional.get());
		return "Vegetable with id "+optional.get().getVegId()+" is removed";
	}


	@Override
	public VegetableDTO viewVegetable(int vegId) throws VegetableIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<VegetableDTO> optional = repository.findById(vegId);
		if (optional.isEmpty()) {
			throw new VegetableIdNotFoundException("Vegetable with id " + vegId + " does not Exist");
		}
		
		return optional.get();
	}

	@Override
	public List<VegetableDTO> viewAllVegetables() {
		// TODO Auto-generated method stub
		List<VegetableDTO> vegetablelist=repository.findAll();
		return vegetablelist;
	}

	@Override
	public List<VegetableDTO> viewVegetableList(String category) {
		// TODO Auto-generated method stub
		List<VegetableDTO> vegetablelist=repository.findAllByCategory(category);
		return  vegetablelist;
	}

	@Override
	public List<VegetableDTO> viewVegetableByName(String name) {
		// TODO Auto-generated method stub
		List<VegetableDTO> vegetablelist=repository.findAllByName(name);
		return vegetablelist;
	}

}


