import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Address } from '../address';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  customer: Customer = new Customer();
  address: Address = new Address();

  submitted = false;

  constructor(private customerService: CustomerService,  private router: Router) { }

  ngOnInit() {
    this.customer = new Customer();
  }

  addCustomer(): void {
    this.submitted = false;
    this.customer = new Customer();
  }

  save() {
    console.log("Customer= "+ this.customer);
    this.customerService.addCustomer(this.customer).subscribe(data => {
      console.log(data)
      this.customer = new Customer();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit(addCustomerForm: { value: any;}) {
    this.submitted = true;
    this.customer.address = this.address
    this.save();    
    console.log(addCustomerForm.value);

  }

  gotoList() {
    this.router.navigate(['/customers']);
  }

}
