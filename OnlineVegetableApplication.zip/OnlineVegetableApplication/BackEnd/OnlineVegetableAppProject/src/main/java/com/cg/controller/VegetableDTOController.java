package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.VegetableDTO;
import com.cg.service.IVegetableMgmtService;
import com.cg.exception.VegetableIdNotFoundException;
@RestController
@RequestMapping("/api")
public class VegetableDTOController {

	@Autowired
	private IVegetableMgmtService service;
	
	@PostMapping("/vegetable/add")
	public VegetableDTO addVegetable(@Valid @RequestBody VegetableDTO dto){
		return service.addVegetable(dto);
		 
	}
	@PutMapping("/vegetable/update/{vegId}")
	public VegetableDTO updateVegetable(@PathVariable(value="vegId")int vegId, @Valid @RequestBody VegetableDTO dto) throws VegetableIdNotFoundException {
		return service.updateVegetable(vegId,dto);
		 
	}
	
	@GetMapping("/vegetable/get/{vegId}")
	public VegetableDTO viewVegetable(@PathVariable(value="vegId")int vegId) throws VegetableIdNotFoundException{
		return service. viewVegetable(vegId);
		
		
	}
	@GetMapping("/vegetable/all")
	public List<VegetableDTO> viewAllVegetables() {
		return service.viewAllVegetables();
		
	}
	@GetMapping("/vegetable/getlistbycat/{category}")
	public List<VegetableDTO> viewVegetableList(@PathVariable(value="category") String category){
		return service.viewVegetableList(category);
		
	}
	@GetMapping("/vegetable/getbyname/{name}")
	public List<VegetableDTO> viewVegetableByName(@PathVariable(value="name") String name){
		return service.viewVegetableByName(name);
	}
	
	@DeleteMapping("/vegetable/remove/{vegId}")
	public String removeVegetable(@PathVariable(value="vegId")int vegId) throws VegetableIdNotFoundException {
		return service.removeVegetable(vegId);
		
	}
	
	

}
