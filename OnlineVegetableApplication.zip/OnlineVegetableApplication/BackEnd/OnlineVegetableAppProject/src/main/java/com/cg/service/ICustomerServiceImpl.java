package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.exception.CustomerIdNotFoundException;
import com.cg.exception.CustomerNotFoundInCityException;
import com.cg.model.Customer;
import com.cg.repository.ICustomerRepository;

@Service
public class ICustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerRepository repository;
	
	@Override
	public Customer addCustomer(Customer customer) {
		return repository.save(customer);
	}

	@Override
	public Customer updateCustomer(int custId,Customer customer) throws CustomerIdNotFoundException {
		Optional<Customer> optional = repository.findById(custId);
		if (optional.isEmpty()) {
			throw new CustomerIdNotFoundException("Customer with id " + custId + " does not Exist");
		}
		optional.get().setCustomerId(custId);
		optional.get().setName(customer.getName());
		optional.get().setMobileNo(customer.getMobileNo());
		optional.get().setEmailId(customer.getEmailId());
		optional.get().setPassword(customer.getPassword());
		optional.get().setConfirmPassword(customer.getConfirmPassword());
		optional.get().setAddress(customer.getAddress());
		return repository.save(optional.get());
	}
	
	
	@Override
	public String removeCustomer(int custId) throws CustomerIdNotFoundException {
		Optional<Customer> optional =repository.findById(custId);
		if (optional.isEmpty()) {
			throw new CustomerIdNotFoundException("Customer with id " + custId + " does not Exist");
		}
		repository.delete(optional.get());
		return "Customer with id "+optional.get().getCustomerId()+" is removed";
	
	} 

	@Override
	public Customer viewCustomer(int custId)throws CustomerIdNotFoundException {
		Optional<Customer> optional = repository.findById(custId);
		if (optional.isEmpty()) {
			throw new CustomerIdNotFoundException("Customer with id " + custId + " does not Exist");
		}

		return optional.get();
	}

	@Override
	public List<Customer> viewCustomerList(String city) throws CustomerNotFoundInCityException {
		List<Customer> customer=repository.findAllByCity(city);
		if(customer.isEmpty()) { 
			throw new CustomerNotFoundInCityException("No Customer in this city");
		}
		return(customer);
	}

	@Override
	public List<Customer> viewAllCustomers() {
		// TODO Auto-generated method stub
		List<Customer> customerList = repository.findAll();
		return customerList;
	}



}
