package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.exception.CustomerIdNotFoundException;
import com.cg.exception.CustomerNotFoundInCityException;
import com.cg.model.Customer;
import com.cg.service.ICustomerService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class CustomerController {

	
		@Autowired
		private ICustomerService service;
		//Add customer into table
		@PostMapping("/customer/add")
		public Customer addCustomer(@Valid @RequestBody Customer customer) {
			System.out.println("Customer "+ customer);
			return service.addCustomer(customer);
			
		}
		//Update Customer details by fetching specific customer using customer id
		@PutMapping("/customer/update/{customerId}")
		public Customer updateCustomer(@PathVariable(value="customerId")int custId,@Valid @RequestBody Customer customer) throws CustomerIdNotFoundException {
			return service.updateCustomer(custId, customer);
			
		}
		
		//get List of the customers present in database
		@GetMapping("/customer/all")
		public List<Customer> viewAllCustomers()
		{
			return service.viewAllCustomers();
		}
		//find customers using city
		@GetMapping("/customer/getall/{city}")
		public List<Customer> viewAllCustomerList(@PathVariable("city") String city)throws CustomerNotFoundInCityException {
			return service.viewCustomerList(city);
		}
		
		//see customer details using customer id
		@GetMapping("/customer/get/{customerId}")
		public Customer getCustomer(@PathVariable(value="customerId")int custId) throws CustomerIdNotFoundException {
			return service.viewCustomer(custId) ;
			
		}
		//delete customer from database
		@DeleteMapping("/customer/remove/{customerId}")
		public String removeCustomer(@PathVariable(value="customerId") int custId)throws CustomerIdNotFoundException {
			return service.removeCustomer(custId);
			
		}
		


	}

