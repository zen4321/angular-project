export class Address
{
    addressId: number=0;
    flatNo: string="" ;
    buildingName: string="";
    area: string="";
    city: string="";
    state: string="";
    pincode: string="";
}