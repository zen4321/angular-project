package com.cg.exception;

public class BillIdNotFoundException extends Exception {
	public BillIdNotFoundException() {
		super();
	}
	public BillIdNotFoundException(String message) {
		super(message);
	}

}
