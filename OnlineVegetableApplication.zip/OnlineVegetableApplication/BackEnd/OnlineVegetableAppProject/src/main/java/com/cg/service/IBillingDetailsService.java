package com.cg.service;

import java.util.List;

import javax.validation.Valid;

import com.cg.dto.BillingDetailsDto;
import com.cg.exception.AddressIdNotFoundException;
import com.cg.exception.BillIdNotFoundException;
import com.cg.exception.OrderIdNotFoundException;
import com.cg.model.BillingDetails;

public interface IBillingDetailsService {
	public BillingDetails addBill(@Valid BillingDetailsDto bill) throws AddressIdNotFoundException, OrderIdNotFoundException;
	public BillingDetails updateBill(int BillingId, BillingDetailsDto billDto) throws BillIdNotFoundException, OrderIdNotFoundException, AddressIdNotFoundException;
	public BillingDetails viewBill(int billId) throws BillIdNotFoundException;
	public List<BillingDetails> viewAllBillingDetails();

}
