package com.cg.dto;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;


public class FeedbackDto {

	@GeneratedValue(strategy = GenerationType.AUTO )
	private int feedbackId;
	private int customerId;
	private int vegetableId;
	private int rating;
	private String comments;
	
	
	public int getFeedbackId() {
		return feedbackId;
	}


	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public int getVegetableId() {
		return vegetableId;
	}


	public void setVegetableId(int vegetableId) {
		this.vegetableId = vegetableId;
	}


	public int getRating() {
		return rating;
	}


	public void setRating(int rating) {
		this.rating = rating;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	
	@Override
	public String toString() {
		return "FeedbackDto [feedbackId=" + feedbackId + ", customerId=" + customerId + ", vegetableId=" + vegetableId
				+ ", rating=" + rating + ", comments=" + comments + "]";
	}


	public FeedbackDto(int feedbackId, int customerId, int vegetableId, int rating, String comments) {
		super();
		this.feedbackId = feedbackId;
		this.customerId = customerId;
		this.vegetableId = vegetableId;
		this.rating = rating;
		this.comments = comments;
	}


	public FeedbackDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
