package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.FeedbackDto;
import com.cg.exception.CustomerIdNotFoundException;
import com.cg.exception.VegetableIdNotFoundException;
import com.cg.model.Customer;
import com.cg.model.Feedback;
import com.cg.model.VegetableDTO;
import com.cg.repository.ICustomerRepository;
import com.cg.repository.IFeedbackRepository;
import com.cg.repository.IVegetableMgmtRepository;


@Service
public class IFeedbackServiceImpl implements IFeedbackService{

	@Autowired
	IFeedbackRepository repository;
	
	@Autowired
	ICustomerRepository custRepo;
	
	@Autowired
	IVegetableMgmtRepository vegRepo;
	
	@Override
	public Feedback addFeedback(FeedbackDto fdk) throws VegetableIdNotFoundException, CustomerIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<Customer> cust = custRepo.findById(fdk.getCustomerId());
		Optional<VegetableDTO> veg = vegRepo.findById(fdk.getVegetableId());
		if(cust.isEmpty())
		{
			throw new CustomerIdNotFoundException("Customer with id "+ fdk.getCustomerId()+"not present");
		}
		if(veg.isEmpty())
		{
			throw new VegetableIdNotFoundException("Vegetable with id "+ fdk.getVegetableId()+"not present");
		}
		Feedback feedback = new Feedback();
		feedback.setFeedbackId(fdk.getFeedbackId());
		feedback.setCustomer(cust.get());
		feedback.setVegetable(veg.get());
		feedback.setRating(fdk.getRating());
		feedback.setComments(fdk.getComments());
		return repository.save(feedback);
	}

	@Override
	public List<Feedback> viewFeedbackByVegId(int vegetableId) throws VegetableIdNotFoundException {
		List<Feedback> feedback = repository.findFeedbackByVegId(vegetableId);
		if (feedback.isEmpty()) {
			throw new VegetableIdNotFoundException("Vegetable with id " + vegetableId + " does not Exist");
		}
		return (feedback);
	}

	@Override
	public List<Feedback> viewFeedbackByCustId(int customerId) throws CustomerIdNotFoundException {
		List<Feedback> feedback = repository.findFeedbackByCustId(customerId);
				if (feedback.isEmpty()) {
					throw new CustomerIdNotFoundException("Vegetable with id " + customerId + " does not Exist");
				}
				return (feedback);
	}

	@Override
	public List<Feedback> viewAllFeedbacks() {
		// TODO Auto-generated method stub
		List<Feedback> allFeedbacks = repository.findAll();
		return allFeedbacks;
	}

}
