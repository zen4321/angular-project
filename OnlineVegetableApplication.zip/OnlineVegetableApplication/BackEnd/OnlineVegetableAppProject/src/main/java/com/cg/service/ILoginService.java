package com.cg.service;

import javax.validation.Valid;

import com.cg.exception.AdminIdNotFoundException;
import com.cg.exception.CustomerIdNotFoundException;
import com.cg.exception.PasswordNotFoundException;
import com.cg.exception.RoleNotFoundException;
import com.cg.exception.UserNotFoundException;
import com.cg.model.User;

public interface ILoginService {
public User validateLogin(User user) throws PasswordNotFoundException, AdminIdNotFoundException, CustomerIdNotFoundException, RoleNotFoundException;
public User logout(User user) throws PasswordNotFoundException, AdminIdNotFoundException, CustomerIdNotFoundException, RoleNotFoundException;
}
