package com.cg.controller;
import java.time.LocalDate;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Order;
import com.cg.service.IOrderService;
import com.cg.exception.OrderIdNotFoundException;
@RestController
@RequestMapping("/api")
public class OrderController {
	@Autowired
	private IOrderService service;
	@PostMapping("/order/add")
	public Order addOrder(@Valid @RequestBody Order order) {
		return service.addOrder(order);
		}
	@PutMapping("/order/update/{orderId}")
	public Order updateOrderDetails(@PathVariable(value="orderId")int orderId,@RequestBody Order order) throws OrderIdNotFoundException {
		return service.updateOrderDetails(orderId,order);
	}
	@GetMapping("/order/get/{orderId}")
	public Order viewOrder(@PathVariable(value="orderId") int orderId) throws OrderIdNotFoundException{
		return service.viewOrder(orderId);
		}
	@GetMapping("/order/getAllOrder/{custId}")
	public List<Order> viewAllOrders(@PathVariable(value="custId") int custId){
		return service.viewAllOrders(custId);
			}
	@GetMapping("/order/getOrderList")
	public List<Order> viewOrderList(){
		return service.viewOrderList();
		 }
	
	@GetMapping("/order/getOrderListByDate/{OrderDate}")
	public List<Order> viewOrderListByDate(@PathVariable(value="OrderDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate OrderDate){
		//List<Order> allOrders= service.viewOrderList(date);
		return service.viewOrderListByDate(OrderDate);
		}
	@DeleteMapping("/order/delete/{orderId}")
	public String cancelOrder(@PathVariable(value="orderId") int orderId) throws OrderIdNotFoundException{
		return service.cancelOrder(orderId);
		}
	


}

