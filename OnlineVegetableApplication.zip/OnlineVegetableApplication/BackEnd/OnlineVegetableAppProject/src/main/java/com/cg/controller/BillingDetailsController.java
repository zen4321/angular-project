package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.BillingDetailsDto;
import com.cg.exception.AddressIdNotFoundException;
import com.cg.exception.BillIdNotFoundException;
import com.cg.exception.OrderIdNotFoundException;
import com.cg.model.BillingDetails;
import com.cg.service.IBillingDetailsService;

@RestController
@RequestMapping("/api")
public class BillingDetailsController {

		
		@Autowired
		private IBillingDetailsService service;
		
		@PostMapping("/billingdetails/add")
		public BillingDetails addBill(@Valid @RequestBody BillingDetailsDto bill) throws AddressIdNotFoundException, OrderIdNotFoundException {
			return  service.addBill(bill);
			 
			}
		@PutMapping("/billingdetails/update/{billingId}")
		public BillingDetails updateBill(@PathVariable(value="billingId")int billingId, @Valid @RequestBody BillingDetailsDto billDto)throws BillIdNotFoundException, OrderIdNotFoundException, AddressIdNotFoundException {
			return service.updateBill(billingId,billDto);
			
		}
		
		@GetMapping("/billingdetails/all")
		public List<BillingDetails> viewAllBillingDetails()
		{
			return service.viewAllBillingDetails();
		}
		@GetMapping("/billingdetails/get/{billingId}")
		public BillingDetails viewBill(@PathVariable(value="billingId")int billingId) throws BillIdNotFoundException {
			return service.viewBill(billingId);
			
		}


}

