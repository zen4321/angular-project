package com.cg.exception;

public class CustomerNotFoundInCityException extends Exception {
	
	public CustomerNotFoundInCityException () {
		super();
	}
	public CustomerNotFoundInCityException (String message) {
		super(message);
	}
	
}
