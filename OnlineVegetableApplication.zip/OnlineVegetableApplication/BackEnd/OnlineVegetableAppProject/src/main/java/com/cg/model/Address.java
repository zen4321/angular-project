package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;


@Entity
@Table(name="address_details")
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	private int addressId;
	@Column(length = 20)
	@NotEmpty(message="Flat no is required")
	private String flatNo;
	@Column(length = 20)
	@NotEmpty(message="Building Name is required")
	private String buildingName;
	@Column(length = 20)
	@NotEmpty(message="Area is required")
	private String area;
	@Column(length = 20)
	@NotEmpty(message="City is required")
	private String city;
	@Column(length = 20)
	@NotEmpty(message="State is required")
	private String state;
	@Column(length = 20)
	@NotEmpty(message="Pincode is required")
	private String pincode;
	public Address() {
		super();
	}
	public Address(String flatNo, String buildingName, String area, String city, String state, String pincode) {
		super();
		this.flatNo = flatNo;
		this.buildingName = buildingName;
		this.area = area;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}
	
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	
	public String getFlatNo() {
		return flatNo;
	}
	public void setFlatNo(String flatNo) {
		this.flatNo = flatNo;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	

	@Override
	public String toString() {
		return "Address [flatNo=" + flatNo + ", buildingName=" + buildingName + ", area=" + area + ", city=" + city
				+ ", state=" + state + ", pincode=" + pincode + "]";


}
}
