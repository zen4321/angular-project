package com.cg.controller;

 

import java.util.List;

import javax.validation.Valid;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

 

import com.cg.exception.AdminIdNotFoundException;
import com.cg.model.Admin;
import com.cg.service.IAdminService;

 

@RestController
@RequestMapping("/api")
public class AdminController {
    @Autowired
    private IAdminService service;
    
    
    @PostMapping("/admin/add")
    public Admin addAdmin(@Valid @RequestBody Admin admin) {
        return service.addAdmin(admin);
         
    }
    @PutMapping("/admin/update/{adminId}")
    public Admin updateAdminDetails(@PathVariable(value="adminId")int adminId,@Valid @RequestBody Admin admin) throws AdminIdNotFoundException {
        return service.updateAdminDetails(adminId, admin);
         
    }
    @GetMapping("/admin/get/{adminId}")
    public Admin viewAdmin(@PathVariable(value="adminId")int adminId) throws AdminIdNotFoundException{
        
        return service.viewAdmin(adminId);
        
    }
    
    
	@GetMapping("/admin/all")
    public List<Admin> viewAllAdmins()
    {
    	return service.viewAllAdmins();
    }
    @DeleteMapping("/admin/remove/{adminId}")
    public String removeAdmin(@PathVariable(value="adminId")int adminId)throws AdminIdNotFoundException {
        return service.removeAdmin(adminId);
        
    }
    

 

}