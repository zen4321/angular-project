package com.cg.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.exception.AdminIdNotFoundException;
import com.cg.exception.CustomerIdNotFoundException;
import com.cg.exception.PasswordNotFoundException;
import com.cg.exception.RoleNotFoundException;
import com.cg.exception.UserNotFoundException;
import com.cg.model.Admin;
import com.cg.model.Customer;
import com.cg.model.User;
import com.cg.repository.IAdminRepository;
import com.cg.repository.ICustomerRepository;
import com.cg.repository.ILoginRepository;

@Service
public class ILoginServiceImpl implements ILoginService {

	@Autowired
	ILoginRepository repository;
	
	@Autowired
	ICustomerRepository custRepo;
	
	@Autowired
	IAdminRepository adminRepo;
	
	@Override
	public User validateLogin(User user) throws PasswordNotFoundException, AdminIdNotFoundException, CustomerIdNotFoundException, RoleNotFoundException 
	{
		
		if(user.getRole().equals("Admin"))
		{
			Optional<Admin> admin=adminRepo.findById(user.getUserId());
			if(admin.isPresent())
			{
				if(admin.get().getPassword().equals(user.getPassword()))
				{
					return user;
				}
				else
				{
					throw new PasswordNotFoundException("Password "+user.getPassword()+"not present");
				}
			}
			else
			{
				throw new AdminIdNotFoundException("Admin with id "+user.getUserId()+"not present");
			}

		}
		else if(user.getRole().equals("Customer"))
		{
			Optional<Customer> cust=custRepo.findById(user.getUserId());
			if(cust.isPresent())
			{
				if(cust.get().getPassword().equals(user.getPassword()))
				{
					return user;
				}
				else
				{
					throw new PasswordNotFoundException("Password "+user.getPassword()+"not present");
				}
			}
			else
			{
				throw new CustomerIdNotFoundException("Customer with id "+user.getUserId()+"not present");
			}
		}
		else {
			throw new RoleNotFoundException("Role "+user.getRole()+" not present");
		}
		

	}

	@Override
	public User logout(User user) throws PasswordNotFoundException, AdminIdNotFoundException, CustomerIdNotFoundException, RoleNotFoundException{

		if(user.getRole().equals("Admin"))
		{
			Optional<Admin> admin=adminRepo.findById(user.getUserId());
			if(admin.isPresent())
			{
				if(admin.get().getPassword().equals(user.getPassword()))
				{
					return user;
				}
				else
				{
					throw new PasswordNotFoundException("Password "+user.getPassword()+"not present");
				}
			}
			else
			{
				throw new AdminIdNotFoundException("Admin with id "+user.getUserId()+"not present");
			}

		}
		else if(user.getRole().equals("Customer"))
		{
			Optional<Customer> cust=custRepo.findById(user.getUserId());
			if(cust.isPresent())
			{
				if(cust.get().getPassword().equals(user.getPassword()))
				{
					return user;
				}
				else
				{
					throw new PasswordNotFoundException("Password "+user.getPassword()+"not present");
				}
			}
			else
			{
				throw new CustomerIdNotFoundException("Customer with id "+user.getUserId()+"not present");
			}
		}
		else {
			throw new RoleNotFoundException("Role "+user.getRole()+"not present");
		}
		
	}

		}
