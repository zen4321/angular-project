package com.cg.service;

import java.util.List;

import com.cg.exception.CustomerIdNotFoundException;
import com.cg.exception.CustomerNotFoundInCityException;
import com.cg.model.Customer;

public interface ICustomerService {
	public Customer addCustomer(Customer customer);
	public Customer updateCustomer(int custId,Customer customer) throws CustomerIdNotFoundException;
	public String removeCustomer(int custId) throws CustomerIdNotFoundException;
	public Customer viewCustomer(int custId) throws CustomerIdNotFoundException;
    public List<Customer> viewCustomerList(String city) throws CustomerNotFoundInCityException;
	public List<Customer> viewAllCustomers();
}
