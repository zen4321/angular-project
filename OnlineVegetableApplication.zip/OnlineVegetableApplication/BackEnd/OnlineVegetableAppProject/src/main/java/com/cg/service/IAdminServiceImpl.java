package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.exception.AdminIdNotFoundException;
import com.cg.model.Admin;
import com.cg.repository.IAdminRepository;
@Service
public class IAdminServiceImpl implements IAdminService{
	
	@Autowired
	IAdminRepository repository;
	
	@Override
	public Admin addAdmin(Admin admin) {
		
		return repository.save(admin);
	}

	@Override
	public Admin updateAdminDetails(int adminId, Admin admin) throws AdminIdNotFoundException {
		Optional<Admin> optional = repository.findById(adminId);
		if (optional.isEmpty()) {
			throw new AdminIdNotFoundException("Admin with id " + adminId + " does not Exist");
		}
		optional.get().setAdminId(adminId);
		optional.get().setName(admin.getName());
		optional.get().setContactNumber(admin.getContactNumber());
		optional.get().setEmailId(admin.getEmailId());
		optional.get().setPassword(admin.getPassword());
		optional.get().setConfirmPassword(admin.getConfirmPassword());
		return repository.save(optional.get());
	}

	@Override
	public String removeAdmin(int adminId) throws AdminIdNotFoundException {
		Optional<Admin> optional = repository.findById(adminId);
		if (optional.isEmpty()) {
			throw new AdminIdNotFoundException("Admin with id " + adminId + " does not Exist");
		}
		repository.delete(optional.get());
		return "Admin with id "+ optional.get().getAdminId()+" is removed!";

	}

	@Override
	public Admin viewAdmin(int adminId) throws AdminIdNotFoundException{
		Optional<Admin> optional = repository.findById(adminId);
		if (optional.isEmpty()) {
			throw new AdminIdNotFoundException("Administrator with id " +adminId + " does not Exist");
		}

		return optional.get();

		
	}

	@Override
	public List<Admin> viewAllAdmins() {
		// TODO Auto-generated method stub
		List<Admin> adminList = repository.findAll();
		return adminList;
	}

}
