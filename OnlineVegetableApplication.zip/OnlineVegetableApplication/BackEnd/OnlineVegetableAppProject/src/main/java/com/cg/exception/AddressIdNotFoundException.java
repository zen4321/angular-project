package com.cg.exception;

public class AddressIdNotFoundException extends Exception{
	public AddressIdNotFoundException() {
		super();
	}

	public AddressIdNotFoundException (String message) {
		super(message);
	}
}