package com.cg.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Cart;
import com.cg.model.Customer;
import com.cg.model.VegetableDTO;
import com.cg.service.ICartService;
import com.cg.exception.CartIdNotFoundException;
import com.cg.exception.CustomerNotFoundInCityException;
import com.cg.exception.VegetableIdNotFoundException;
@RestController
@RequestMapping("/api")
public class CartController {
	@Autowired
    private ICartService icart;
   
    @PostMapping("/cart/addcart")
    public Cart addcart(@Valid @RequestBody Cart cart)
    {
        return icart.addCart(cart);
    }
   
    @PostMapping("/cart/add/{cartId}")
    public VegetableDTO addToCart(@PathVariable(value="cartId") int cartId,@Valid @RequestBody VegetableDTO item)throws CartIdNotFoundException {
        return icart.addToCart(cartId, item);
            
    }
   
    @PutMapping("/cart/increaseitem/{cartId}/{vegId}/{quantity}")
    public Cart increaseVegQuantity(@PathVariable(value="vegId") int vegId,@PathVariable(value="cartId")int cartId,
            @PathVariable(value="quantity")int quantity) throws CartIdNotFoundException {
        return icart.increaseVegQuantity(cartId,vegId,quantity);
       
    }
   
    @PutMapping("/cart/descitem/{cartId}/{vegId}/{quantity}")
    public Cart descVegQuantity(@PathVariable(value="vegId") int vegId,@PathVariable(value="cartId")int cartId,
            @PathVariable(value="quantity")int quantity) throws CartIdNotFoundException {
        return icart.decreseVegQuantity(cartId,vegId,quantity);
       
    }
   
    @GetMapping("/cart/viewcart/{cartId}")
    public Cart viewcart(@PathVariable(value="cartId") int cartId)
    {
        return icart.viewCart(cartId);
    }
   
    @GetMapping("/cart/getall/{cartId}")
	public List<VegetableDTO> viewAllItems(@PathVariable(value="cartId") int cartId)throws CartIdNotFoundException {
		return icart.viewAllItems(cartId);
	}
    
    @GetMapping("/cart/all")
    public List<Cart> viewAllCarts()
    {
    	return icart.viewAllCarts();
    }
    
//    @DeleteMapping("/cart/remove/{cartId}/{vegId}")
//    public Cart removeVegetable(@PathVariable(value="cartId") int cartId,@PathVariable(value="vegId") int vegId) throws CartIdNotFoundException, VegetableIdNotFoundException{
//        return icart.removeVegetable(cartId,vegId);
//       
//    }
//    
    @DeleteMapping("/cart/remove/{cartId}")
    public String removeAllItems(@PathVariable(value="cartId") int cartId) throws CartIdNotFoundException{
        return icart.removeAllItems(cartId);
       
    }
}