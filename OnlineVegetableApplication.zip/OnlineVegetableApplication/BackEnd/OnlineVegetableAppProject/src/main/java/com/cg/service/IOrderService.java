package com.cg.service;
import java.time.LocalDate;
import java.util.List;

import com.cg.model.Order;
import com.cg.exception.OrderIdNotFoundException;


public interface IOrderService {
	public Order addOrder(Order order) ;
	public Order viewOrder(int orderNo) throws OrderIdNotFoundException ;
	public Order updateOrderDetails(int orderId,Order order) throws OrderIdNotFoundException  ;
	public List<Order> viewAllOrders(int custid) ;
	public List<Order> viewOrderListByDate(LocalDate date)  ;
	public List<Order> viewOrderList() ;
	public String cancelOrder(int orderNo) throws OrderIdNotFoundException;

}

