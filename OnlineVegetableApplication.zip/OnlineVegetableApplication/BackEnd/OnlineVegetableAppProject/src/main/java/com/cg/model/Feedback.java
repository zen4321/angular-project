package com.cg.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name="feedback_details")
public class Feedback 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	private int feedbackId;
	@ManyToOne//(fetch = FetchType.EAGER)
    @JoinColumn(name = "customerId")
	private Customer customer;
	@OneToOne
	@JoinColumn(name="vegId")
	private VegetableDTO vegetable;
	private int rating;
	@Column(length = 20)
	@NotEmpty(message="Comments is required")
	private String comments;
	public Feedback() {
		super();
	}
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public VegetableDTO getVegetable() {
		return vegetable;
	}
	public void setVegetable(VegetableDTO vegetable) {
		this.vegetable = vegetable;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", customer=" + customer + ", vegetable=" + vegetable
				+ ", rating=" + rating + ", comments=" + comments + "]";
	}
	public Feedback(int feedbackId, Customer customer, VegetableDTO vegetable, int rating, String comments) {
		super();
		this.feedbackId = feedbackId;
		this.customer = customer;
		this.vegetable = vegetable;
		this.rating = rating;
		this.comments = comments;
	}
	
	
	
	
}
