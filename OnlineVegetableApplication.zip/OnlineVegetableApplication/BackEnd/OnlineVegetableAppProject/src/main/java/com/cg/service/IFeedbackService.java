package com.cg.service;

import java.util.List;

import com.cg.dto.FeedbackDto;
import com.cg.exception.CustomerIdNotFoundException;
import com.cg.exception.VegetableIdNotFoundException;
import com.cg.model.Feedback;

public interface IFeedbackService {


	public Feedback addFeedback(FeedbackDto fdk) throws VegetableIdNotFoundException, CustomerIdNotFoundException;

	public List<Feedback> viewFeedbackByCustId(int customerId) throws CustomerIdNotFoundException;

	public List<Feedback> viewFeedbackByVegId(int vegetableId) throws VegetableIdNotFoundException;

	public List<Feedback> viewAllFeedbacks();

	
}
