package com.cg.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
@Table(name="billing_details")
public class BillingDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	private int billingId;
	@OneToOne
	@JoinColumn(name="orderId")
	private Order order;
	@Column(length = 20)
	@NotEmpty(message="Transaction Mode is required")
	private String transactionMode;
	private LocalDate transactionDate;
	@Column(length = 20)
	@NotEmpty(message="Transaction Status is required")
	private String transactionStatus;
	
	@OneToOne//(cascade=CascadeType.MERGE)
	@JoinColumn(name="addressId")
	private Address address;
	public BillingDetails() {
		super();

	}
	public int getBillingId() {
		return billingId;
	}
	public void setBillingId(int billingId) {
		this.billingId = billingId;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public String getTransactionMode() {
		return transactionMode;
	}
	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "BillingDetails [billingId=" + billingId + ", order=" + order + ", transactionMode=" + transactionMode
				+ ", transactionDate=" + transactionDate + ", transactionStatus=" + transactionStatus + ", address="
				+ address + "]";
	}
	public BillingDetails(int billingId, Order order, String transactionMode, LocalDate transactionDate,
			String transactionStatus, Address address) {
		super();
		this.billingId = billingId;
		this.order = order;
		this.transactionMode = transactionMode;
		this.transactionDate = transactionDate;
		this.transactionStatus = transactionStatus;
		this.address = address;
	}
	
	
}
