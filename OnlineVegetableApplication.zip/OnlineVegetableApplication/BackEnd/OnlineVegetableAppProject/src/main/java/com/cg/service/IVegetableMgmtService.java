package com.cg.service;


import java.util.List;

import com.cg.model.VegetableDTO;
import com.cg.exception.VegetableIdNotFoundException;


public interface IVegetableMgmtService {
	public VegetableDTO addVegetable(VegetableDTO dto);
	public VegetableDTO updateVegetable(int vegId,VegetableDTO dto) throws VegetableIdNotFoundException ;
	public String removeVegetable(int vegId) throws VegetableIdNotFoundException ;
	public VegetableDTO viewVegetable(int vegId)  throws VegetableIdNotFoundException ;
	public List<VegetableDTO> viewAllVegetables() ;
	public List<VegetableDTO> viewVegetableList(String category) ;
	public List<VegetableDTO> viewVegetableByName(String name) ;

}
