package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.exception.AdminIdNotFoundException;
import com.cg.exception.CustomerIdNotFoundException;
import com.cg.exception.PasswordNotFoundException;
import com.cg.exception.RoleNotFoundException;
import com.cg.exception.UserNotFoundException;
import com.cg.model.User;
import com.cg.service.ILoginService;


@RestController
@RequestMapping("/api")
public class LoginController {
	
	@Autowired
	ILoginService service;
	
	@PostMapping("/user/login")
	 public String validateUser(@RequestBody User user) throws UserNotFoundException, PasswordNotFoundException, AdminIdNotFoundException, CustomerIdNotFoundException, RoleNotFoundException {
		User user1=service.validateLogin(user);
		return (user1.getUserId()+" Logged in successfully");
	}
	
	@PostMapping("/user/logout")
	 public String logout(@RequestBody User user) throws UserNotFoundException, PasswordNotFoundException, AdminIdNotFoundException, CustomerIdNotFoundException, RoleNotFoundException {
		User user1=service.logout(user);
		return (user1.getUserId()+" Logged out successfully");
		}
	

}

