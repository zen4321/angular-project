package com.cg.exception;

public class PasswordNotFoundException extends Exception{
	
	public PasswordNotFoundException() {
		super();
	}
	public PasswordNotFoundException(String message) {
		super(message);
	}
}
