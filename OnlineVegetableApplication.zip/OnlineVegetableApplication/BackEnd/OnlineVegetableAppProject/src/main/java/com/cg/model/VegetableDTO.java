package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
@Entity
@Table(name="Vegetable_details")
public class VegetableDTO {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	private int vegId;
	@Column(length = 20)
	@NotEmpty(message="Name is required")
	private String name;
	@Column(length = 20)
	@NotEmpty(message="Type is required")
	private String type;
	@Column(length = 20)
	@NotEmpty(message="Category is required")
	private String category;
	private double price;
	private int quantity;
	public VegetableDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public VegetableDTO(int vegId, String name, String type, String category, double price, int quantity) {
		super();
		this.vegId = vegId;
		this.name = name;
		this.type = type;
		this.category = category;
		this.price = price;
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "VegetableDTO [vegId=" + vegId + ", name=" + name + ", type=" + type + ", category=" + category
				+ ", price=" + price + ", quantity=" + quantity + "]";
	}
	public int getVegId() {
		return vegId;
	}
	public void setVegId(int vegId) {
		this.vegId = vegId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	

     
}
	