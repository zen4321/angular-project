package com.cg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.model.Feedback;

@Repository
public interface IFeedbackRepository extends JpaRepository<Feedback, Integer>{

	@Query("select f from Feedback f where f.vegetable.vegId=:vegetableId")
	List<Feedback> findFeedbackByVegId(@Param(value="vegetableId")int vegetableId);
	
	@Query("select f from Feedback f where f.customer.customerId=:customerId")
	List<Feedback> findFeedbackByCustId(@Param(value="customerId")int customerId);
}
