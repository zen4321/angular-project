package com.cg.service;

import java.util.List;

import com.cg.exception.AdminIdNotFoundException;
import com.cg.model.Admin;

public interface IAdminService {
	public Admin addAdmin(Admin admin);
	public Admin updateAdminDetails(int adminId,Admin admin) throws AdminIdNotFoundException;
	public List<Admin> viewAllAdmins();
	public String removeAdmin(int adminId) throws AdminIdNotFoundException;
	public Admin viewAdmin(int adminId) throws AdminIdNotFoundException;
}
