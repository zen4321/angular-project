package com.cg.exception;

public class RoleNotFoundException extends Exception {

	public RoleNotFoundException() {
		super();
	}
	public RoleNotFoundException(String message) {
		super(message);
	}
}
