package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.repository.*;
import com.cg.model.Cart;
import com.cg.model.VegetableDTO;
import com.cg.exception.CartIdNotFoundException;
import com.cg.exception.VegetableIdNotFoundException;


@Service
public class ICartServiceImpl implements ICartService {

	@Autowired
	private ICartRepository cartRepository;
	
	@Autowired
	IVegetableMgmtRepository vegRepository;
	

	@Override
	public Cart addCart(Cart cart) {
		// TODO Auto-generated method stub
		return cartRepository.save(cart);
	}

	@Override
	public Cart viewCart(int cartId) {
		// TODO Auto-generated method stub
		Optional<Cart> optionalcart=cartRepository.findById(cartId);
		return optionalcart.get();
	}

	@Override
	public VegetableDTO addToCart(int cartId, VegetableDTO dto)throws CartIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<VegetableDTO> optionalVeg = vegRepository.findById(dto.getVegId());
		Optional<Cart> cart1=cartRepository.findById(cartId);
		if(cart1.isPresent())
		{
		if (optionalVeg.isPresent()) {
			
			cart1.get().getVegetables().add(dto);
			cartRepository.saveAndFlush(cart1.get());
		}
		}
		else
		{
			throw new CartIdNotFoundException("Cart with id "+cartId+" not found Exception");
		}
		
		return dto;

	}

//	@Override
//	public Cart removeVegetable(int cartId,int vegId) throws VegetableIdNotFoundException, CartIdNotFoundException {
//		
//			Optional<Cart> optionalcart = cartRepository.findById(cartId);
//			Cart cart2 = null;
//			if (optionalcart.isPresent()) {
//				cart2 = optionalcart.get();
//				List<VegetableDTO> vegetableInCart = cart2.getVegetables();
//				for (VegetableDTO veg : vegetableInCart) {
//					if (veg.getVegId() == vegId) {
//						cartRepository.deleteById(vegId);}
//					
//				}
//				
//				return cart2;
//			} 
//			else {
//					throw new CartIdNotFoundException("Cart with id"+cartId+"not found Exception");
//			}
//		
//
//	}

	@Override
	public Cart increaseVegQuantity(int cartid, int vegId, int quantity) throws CartIdNotFoundException {
		
			Cart cart = null;
			Optional<Cart> optionalcart = cartRepository.findById(cartid);
			if (optionalcart.isPresent()) {
				cart = optionalcart.get();
				List<VegetableDTO> vegetableInCart = cart.getVegetables();
				for (VegetableDTO veg : vegetableInCart) {
					if (veg.getVegId() == vegId) {
						veg.setQuantity(veg.getQuantity() + quantity);
					}
				}
				return cart;
				
				
			}
			else
			{
				throw new CartIdNotFoundException("Cart with id"+cartid+"not found Exception");
			}
			

	}

	@Override
	public Cart decreseVegQuantity(int cartid, int vegId, int quantity)throws CartIdNotFoundException{
		
			Cart cart = null;
			Optional<Cart> optionalcart = cartRepository.findById(cartid);
			if (optionalcart.isPresent()) {
				cart = optionalcart.get();
				List<VegetableDTO> vegetableInCart = cart.getVegetables();
				for (VegetableDTO veg : vegetableInCart) {
					if (veg.getVegId() == vegId) {
						veg.setQuantity(veg.getQuantity() - quantity);
					}
				}
				return cart;
			}
			else
			{
				throw new CartIdNotFoundException("Cart with id"+cartid+"not found Exception");
			}
			
		

	}

	@Override
	public List<VegetableDTO> viewAllItems(int cartId) throws CartIdNotFoundException {
		
			Optional<Cart> cartoptional = null;
			cartoptional = cartRepository.findById(cartId);
			if (cartoptional.isPresent()) {
				Cart cart2 = cartoptional.get();
				return cart2.getVegetables();
			}
			else
			{
				throw new CartIdNotFoundException("Cart with id"+cartId+"not found Exception");
			}

		
		
	}


	
	@Override
	public String removeAllItems(int cartId) throws CartIdNotFoundException {
		
		Optional<Cart> cartoptional = null;
		cartoptional = cartRepository.findById(cartId);
		if (cartoptional.isEmpty())
			{
			throw new CartIdNotFoundException("Cart with id "+ cartId+" not found ");
		
			
			}
			cartRepository.deleteById(cartId);
			return ("Cart with id "+cartId+" successfully removed");
		
	}

	@Override
	public List<Cart> viewAllCarts() {
		// TODO Auto-generated method stub
		List<Cart> allCarts = cartRepository.findAll();
		return allCarts;
	}




}
