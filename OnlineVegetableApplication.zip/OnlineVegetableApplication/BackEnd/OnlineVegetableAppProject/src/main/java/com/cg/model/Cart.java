package com.cg.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="cart_details")
public class Cart {
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int cartId;
		@OneToOne
		@JoinColumn(name="customerId")
		private Customer customer;
		@OneToMany
	    private List<VegetableDTO> vegetables;
		
		public Cart() {
			super();
		}
		public int getCartId() {
			return cartId;
		}
		public void setCartId(int cartId) {
			this.cartId = cartId;
		}
		public Customer getCustomer() {
			return customer;
		}
		public void setCustomer(Customer customer) {
			this.customer = customer;
		}
		public List<VegetableDTO> getVegetables() {
			return vegetables;
		}
		public void setVegetables(List<VegetableDTO> vegetables) {
			this.vegetables = vegetables;
		}
		@Override
		public String toString() {
			return "Cart [cartId=" + cartId + ", customer=" + customer + ", vegetables=" + vegetables + "]";
		}
		public Cart(int cartId, Customer customer, List<VegetableDTO> vegetables) {
			super();
			this.cartId = cartId;
			this.customer = customer;
			this.vegetables = vegetables;
		}
		
	}

	
		
		

