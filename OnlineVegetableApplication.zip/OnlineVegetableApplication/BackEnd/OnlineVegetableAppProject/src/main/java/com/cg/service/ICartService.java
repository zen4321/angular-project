package com.cg.service;

import java.util.List;

import com.cg.model.Cart;
import com.cg.model.VegetableDTO;
import com.cg.exception.CartIdNotFoundException;
import com.cg.exception.VegetableIdNotFoundException;


public interface ICartService {
	
	public VegetableDTO addToCart(int cartId,VegetableDTO dto) throws CartIdNotFoundException;
//	public Cart removeVegetable(int cartId,int vegId) throws VegetableIdNotFoundException, CartIdNotFoundException ;
	public Cart increaseVegQuantity(int vegId,int quantity,int cartId) throws CartIdNotFoundException ;
	public Cart decreseVegQuantity(int vegId,int quantity,int cartId) throws CartIdNotFoundException ;
	public List<VegetableDTO> viewAllItems(int cartId) throws CartIdNotFoundException;
	public String removeAllItems(int cartId) throws CartIdNotFoundException ;
	public Cart addCart(Cart cart);
	public Cart viewCart(int cartId);
	public List<Cart> viewAllCarts();

}

