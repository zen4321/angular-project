package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.FeedbackDto;
import com.cg.exception.CustomerIdNotFoundException;
import com.cg.exception.VegetableIdNotFoundException;
import com.cg.model.Feedback;
import com.cg.service.IFeedbackService;


@RestController
@RequestMapping("/api")
public class FeedbackController {
	@Autowired
	private IFeedbackService service;
	
	
	@PostMapping("/feedback/add")
	public Feedback addFeedback(@Valid @RequestBody FeedbackDto fdk) throws VegetableIdNotFoundException, CustomerIdNotFoundException {
		return service.addFeedback(fdk);
		
	}
	@GetMapping("/feedback/getByVeg/{vegetableId}")
	public List<Feedback> viewFeedbackByVegId(@PathVariable(value="vegetableId")int vegetableId) throws VegetableIdNotFoundException{
		//List<Feedback> allFeedback=service.viewFeedbackByVegId(vegetableId);
		return service.viewFeedbackByVegId(vegetableId);
	}
	
	@GetMapping("/feedback/all")
	public List<Feedback> viewAllFeedbacks()
	{
		return service.viewAllFeedbacks();
	}
	@GetMapping("/feedback/getByCust/{customerId}")
	public List<Feedback> viewFeedbackByCustId(@PathVariable(value="customerId")int customerId) throws CustomerIdNotFoundException{
		//List<Feedback> Feedback=service.viewFeedbackByCustId(customerId);
		return service.viewFeedbackByCustId(customerId);
	}
}
