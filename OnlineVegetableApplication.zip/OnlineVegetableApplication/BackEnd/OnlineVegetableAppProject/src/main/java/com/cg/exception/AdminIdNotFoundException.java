package com.cg.exception;


public class AdminIdNotFoundException extends Exception{
	
	public AdminIdNotFoundException() {
		super();
	}
	public AdminIdNotFoundException(String message) {
		super(message);
	}
	
}
