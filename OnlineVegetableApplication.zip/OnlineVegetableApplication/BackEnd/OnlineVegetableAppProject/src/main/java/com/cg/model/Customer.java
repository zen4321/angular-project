package com.cg.model;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name="customer_details")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	private int customerId;
	@Column(length = 20)
	@NotEmpty(message="Name is required")
	private String name;
	@Column(length = 20)
	@NotEmpty(message="Mobile Number is required")
	private String mobileNo;
	@Column(length = 20)
	@NotEmpty(message="Email Id is required")
	@Email(message="Not a valid Email")
	private String emailId;
	@Column(length = 20)
	@NotEmpty(message="Password is required")
	private String password;
	@Column(length = 20)
	@NotEmpty(message="Confirm Password is required")
	private String confirmPassword;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="addressId")
	private Address address;
	public Customer() {
		super();
	}
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

//	public void addFeedback(Feedback feedback) {
//		feedback.setCustomer(this);			
//		this.getFeedbacks().add(feedback);
//	}

	public Customer(int customerId, String name, String mobileNo, String emailId, String password,
			String confirmPassword, Address address) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", mobileNo=" + mobileNo + ", emailId="
				+ emailId + ", password=" + password + ", confirmPassword=" + confirmPassword + ", address=" + address
				+ "]";
	}
	
}
