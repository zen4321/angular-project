import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {


  private baseUrl = 'http://localhost:8080/api/customer';

  constructor(private http: HttpClient) { }

  
//Add customer into database
  addCustomer(customer: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/add`, customer);
  }

  //Update customer details
  updateCustomer(customerId: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/update/${customerId}`, value);
  }
  //see Customer details by fetching specific user using custId
  getCustomer(customerId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/get/${customerId}`);
  }

  //View all customers present in the database
  viewAllCustomers(): Observable<any> {
    return this.http.get(`${this.baseUrl}/all`);
  }
//Remove customer from database
  removeCustomer(customerId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/remove/${customerId}`, { responseType: 'text' });
  }
}
