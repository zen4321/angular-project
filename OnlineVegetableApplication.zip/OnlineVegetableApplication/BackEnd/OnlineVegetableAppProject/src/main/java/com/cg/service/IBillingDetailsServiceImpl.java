package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.BillingDetailsDto;
import com.cg.exception.AddressIdNotFoundException;
import com.cg.exception.BillIdNotFoundException;
import com.cg.exception.OrderIdNotFoundException;
import com.cg.model.Address;
import com.cg.model.BillingDetails;
import com.cg.model.Order;
import com.cg.repository.IAddressRepository;
import com.cg.repository.IBillingDetailsRepository;
import com.cg.repository.ICustomerRepository;
import com.cg.repository.IOrderRepository;


@Service
public class IBillingDetailsServiceImpl implements IBillingDetailsService {
	
	@Autowired
	IBillingDetailsRepository repository;
	
	@Autowired
	IAddressRepository addressRepo;
	
	@Autowired
	IOrderRepository orderRepo;

	@Override
	public BillingDetails addBill(BillingDetailsDto billDto) throws AddressIdNotFoundException, OrderIdNotFoundException {
		Optional<Address> address = addressRepo.findById(billDto.getAddressId());
		Optional<Order> order = orderRepo.findById(billDto.getOrderId());
		if(address.isEmpty())
		{
			throw new AddressIdNotFoundException("Address with id "+billDto.getAddressId()+"Not Present");
		}
		if(order.isEmpty())
		{
			throw new OrderIdNotFoundException("Order with id "+billDto.getOrderId()+"Not Present");
		}
		BillingDetails bill = new BillingDetails();
		bill.setBillingId(billDto.getBillingId());
		bill.setOrder(order.get());
		bill.setTransactionMode(billDto.getTransactionMode());
		bill.setTransactionDate(billDto.getTransactionDate());
		bill.setTransactionStatus(billDto.getTransactionStatus());
		bill.setAddress(address.get());
		repository.save(bill);
		return bill;
	}

	@Override
	public BillingDetails updateBill(int BillingId,BillingDetailsDto billDto) throws BillIdNotFoundException, OrderIdNotFoundException, AddressIdNotFoundException {
		Optional<BillingDetails> optional = repository.findById(BillingId);
		if (optional.isEmpty()) {
			throw new BillIdNotFoundException("Bill with id " + BillingId + " does not Exist");
		}
		Optional<Address> address = addressRepo.findById(billDto.getAddressId());
		Optional<Order> order = orderRepo.findById(billDto.getOrderId());
		if(address.isEmpty())
		{
			throw new AddressIdNotFoundException("Address with id "+billDto.getAddressId()+"Not Present");
		}
		if(order.isEmpty())
		{
			throw new OrderIdNotFoundException("Order with id "+billDto.getOrderId()+"Not Present");
		}
		optional.get().setBillingId(billDto.getBillingId());
		optional.get().setOrder(order.get());
		optional.get().setTransactionMode(billDto.getTransactionMode());
		optional.get().setTransactionDate(billDto.getTransactionDate());
		optional.get().setTransactionStatus(billDto.getTransactionStatus());
		optional.get().setAddress(address.get());
		repository.save(optional.get());
		return optional.get();
		
	}

	@Override
	public BillingDetails viewBill(int billId)  throws BillIdNotFoundException {

				Optional<BillingDetails> optional = repository.findById(billId);
				if (optional.isEmpty()) {
					throw new BillIdNotFoundException("Bill with id " + billId+ " does not Exist");
				}
				
				return optional.get();
			}

	@Override
	public List<BillingDetails> viewAllBillingDetails() {
		// TODO Auto-generated method stub
		List<BillingDetails> allBillingDetails = repository.findAll();
		return allBillingDetails;
	}
}
